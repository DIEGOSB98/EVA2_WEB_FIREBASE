Theme usage licese: 
(You cannot redistribute our templates/products on any thrid party websites which offers the file to download.)

Regular Liceses terms

Do's:
> Downloaded templates under this license grants you to use templates in any personal or business project without any charge.
> Highly appreciated if keeping the credits on the footer to our site UiGrid, but not mandatory.
> You may modify the templates according to your requirements and use them for free.

Dont�s:
> You cannot reproduce, create or recreate duplicate, copy, sell, resell or redistibute our templates for downloads on any other third party websites without any writen or granted permission by UiGrid
> You cannot redistribute our templates/products on any thrid party websites which offers the file to download.
> You are not permitted to convert a template to a CMS theme to sell or distribute for free.
> We don�t provide support for free templates, you can hire us to customize, modify or make changes in your ordered/purchased templates.

> Contact us here at example@gmail.com to request template customization.


www.uigrid.com
Email: help@uigrid.com

Website Themes and Templates

https://www.facebook.com/uigridcom
https://www.twitter.com/uigridcom
https://plus.google.com/+UiGridMarketplace
https://in.pinterest.com/uigrid/